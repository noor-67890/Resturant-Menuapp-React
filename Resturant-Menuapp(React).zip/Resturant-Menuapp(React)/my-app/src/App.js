import Resturant from './component/Resturant'
import React from 'react'

const App = () => {
  return (
    <div>
      <Resturant/>
    </div>
  )
}

export default App;

